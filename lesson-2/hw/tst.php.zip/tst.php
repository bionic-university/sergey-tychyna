<?php
include(getcwd().'/palindromdetector.php');
new PalindromDetector();
